Group work; roles & assignment.

Daniall M. { Role ("Team Kordinator"); Code Assignment ("RecordKeeper and cards"); Report Assignment ("Requirements/Analysis, Design, Implementation & Testing"); }

Andrei E. { Role ("Developer, Reporter & Checker"), Code Assignment ("Main adjacent classes and tiles"), Report Assignment ("Implementation, Testing & Konfiguration"); }

Abdullah H. { Role ("Developer, Reporter & Reader"), Code Assignment ("BoardUI"), Report Assignment ("Introduction, Requirements/Analysis, Design & Conlusion"); }

Samin C. { Role ("Developer, Reporter & Reader"), Code Assignment ("Languages"), Report Assignment ("Introduction, Requirements/Analysis, Design & Conlusion"); }
